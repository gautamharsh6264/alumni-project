<?php
error_reporting(0);
session_start();
?>
<?php
include("header.php");
/* ### */  ?>

<div class="content">
<!--welcome-->
		<div class="col-top" >
	<div class="container">
	
			<h3>About </h3>	
		
		<div class="content-top" >
			<div class="col-md-4 content-top-1 animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
				<h4>Alumni today are the best source of jobs, donation & knowledge capital for you institute,
so get them back by signing up for ALUMNI today! </h4>	
			</div>
			<div class="col-md-8 content-top-2 animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
			
			  <p>Alumni of a college generally stay in touch with their immediate friends but find it hard to stay connected with other college mates. Contact between alumni can be used to forge business connections and to gain references or insight in a new field. Alumni work can consist of alumni mentoring students, organizing alumni days, having training sessions during alumni days for alumni, inviting alumni to give lectures, arranging work practices, and proposing topics of theses, raise funds for the organizations. It is important to carry out a good follow-up marketing of alumni events.</p> 
			 <p>&nbsp;</p>
			<p>ALUMNI helps institutes strategically build and manage their alumni network, by facilitating engagement, community-building, networking, communications and giving back. With ALUMNI, your Alumni data can be centralized and combined with a host of exciting front-end member modules and time-saving, back-end administration tools.</p>
						
			</div>
			<div class="clearfix"></div>
		</div>
		</div>
		</div>
		
		 <?php
include("footer.php");
/* ### */  ?>